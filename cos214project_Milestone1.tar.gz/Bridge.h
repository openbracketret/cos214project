#ifndef BRIDGE_H
#define BRIDGE_H

#include "SpaceshipDecorator.h"

class Bridge : public SpaceshipDecorator {

    public:
        Bridge();
        ~Bridge();


};

#endif