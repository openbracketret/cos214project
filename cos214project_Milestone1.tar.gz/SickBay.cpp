#include "SickBay.h"

SickBay::SickBay() : SpaceshipDecorator() {

}

SickBay::~SickBay() {
    
}