#ifndef ARMORY_H
#define ARMORY_H

#include "SpaceshipDecorator.h"

class Armory : public SpaceshipDecorator {
    public:
        Armory();
        ~Armory();
};

#endif