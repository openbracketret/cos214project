#include "SpaceshipFactory.h"

using namespace std;

SpaceshipFactory()
{
	
}

~SpaceshipFactory()
{

}