#include "Armory.h"

Armory::Armory() : SpaceshipDecorator() {

}

Armory::~Armory(){
    
}