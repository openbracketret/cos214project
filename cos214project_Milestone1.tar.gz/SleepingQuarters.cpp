#include "SleepingQuarters.h"

SleepingQuarters::SleepingQuarters() : SpaceshipDecorator() {

}

SleepingQuarters::~SleepingQuarters(){
        
}