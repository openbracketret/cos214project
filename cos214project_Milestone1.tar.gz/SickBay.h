#ifndef SICKBAY_H
#define SICKBAY_H

#include "SpaceshipDecorator.h"

class SickBay : public SpaceshipDecorator{

    public:
        SickBay();
        ~SickBay();
};

#endif