#include "Bridge.h"

Bridge::Bridge() : SpaceshipDecorator() {

}

Bridge::~Bridge() {
    
}